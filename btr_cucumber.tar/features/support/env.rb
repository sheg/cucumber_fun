require 'rspec-expectations'
require 'page-object'
require 'page-object/page_factory'
require 'data_magic'


World(PageObject::PageFactory)
